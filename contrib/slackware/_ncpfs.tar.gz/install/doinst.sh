( cd usr/bin ; rm -rf ncplogout )
( cd usr/bin ; ln -sf /usr/bin/ncpumount ncplogout )
( cd usr/man/man8 ; rm -rf mount.ncp.8.gz )
( cd usr/man/man8 ; ln -sf ncpmount.8.gz mount.ncp.8.gz )
/sbin/ldconfig

